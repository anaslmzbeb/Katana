#pragma once

#define HTTP_SERVER "89.42.88.222"
#define HTTP_PORT 80

#define TFTP_SERVER "89.42.88.222"
